<?php
	
	class AccountAccess extends Controller{

		protected $model;

		public function __construct(){
			$this->model=new Account;
		}

		public function verifyAdminLogin(){
			$data=extract($_POST);
			$result=$this->model->verifyAdminAccount($username,$password);
			if($result == 0){return 0;}
		    elseif($result == 1){return 1;}
		    elseif($result == 2){ return 2;}
		    else{return 3;} 
		}
		    
 

		//Register/Create User Account
		public function registerUser(){
			extract($_POST);
			if(!isset($_POST["referal"])){$referal="";}
			$check=$this->model->registerUser($fname,$lname,$email,$phone,$password,$state,$account,$referal,$transpin);
			return $check;
		}

		//Login User Account
		public function loginUser(){
			extract($_POST);
			$check=$this->model->loginUser($phone,$password);
			return $check;
		}

		//Recover User Account
		public function recoverUserLogin(){
			extract($_POST);
			$check=$this->model->recoverUserLogin($email);
			return $check;
		}

		//Recover User Account
		public function verifyRecoveryCode(){
			extract($_POST);
			$check=$this->model->verifyRecoveryCode($email,$code);
			return $check;
		}

		//Recover Seller Account
		public function updateUserKey(){
			extract($_POST);
			$check=$this->model->updateUserKey($email,$code,$password);
			return $check;
		}

	}

?>