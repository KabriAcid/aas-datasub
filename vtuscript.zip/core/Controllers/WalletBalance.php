<?php

    class WalletBalance extends ApiAccess{

        //Get Wallet Balance
		public function getWalletBalance($wallet){

			$response = array();
            $details=$this->model->getApiDetails();

            if($wallet == "one"){$name="walletOneApi"; $name2="walletOneProvider"; $name3="walletOneProviderName";}
            if($wallet == "two"){$name="walletTwoApi"; $name2="walletTwoProvider"; $name3="walletTwoProviderName";}
            if($wallet == "three"){$name="walletThreeApi"; $name2="walletThreeProvider"; $name3="walletThreeProviderName";}

            $apiKey=self::getConfigValue($details,$name);
            $hostuserurl=self::getConfigValue($details,$name2);
            $apiProvider=self::getConfigValue($details,$name3);

            $aunType = "Basic";
            if(strpos($hostuserurl, 'n3tdata') !== false){$aunType = "Basic";}
            elseif (strpos($hostuserurl, 'bilalsadasub') !== false){$aunType = "Basic";}
            else{$aunType = "Token";}

            // ------------------------------------------
            //  Get User Access Token
            // ------------------------------------------
            
            $curlA = curl_init();
            curl_setopt_array($curlA, array(
                CURLOPT_URL => $hostuserurl,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'GET',
                CURLOPT_HTTPHEADER => array(
                    "Authorization: $aunType  $apiKey",
                    'Content-Type: application/json'
                ),
            ));
        
            $exereqA = curl_exec($curlA);
            $result=json_decode($exereqA);
            curl_close($curlA);

            if(isset($result->user->wallet_balance)){
                $response["status"] = "success";
                $response["balance"] = $result->user->wallet_balance;
            }
            elseif(isset($result->wallet_balance)){
                $response["status"] = "success";
                $response["balance"] = $result->wallet_balance;
            }
            elseif(isset($result->balance)){
                $response["status"] = "success";
                $response["balance"] = $result->balance;
            }
            else{
                $response["status"] = "fail";
                $response["balance"] = "0";
            }

            $response["provider"] = $apiProvider;
            
            return $response;
        }   
        
    }

?>