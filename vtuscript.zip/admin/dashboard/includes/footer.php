<footer class="main-footer text-center">
    <i>&copy; <?php echo date("Y"); ?> . <a href="https://topupmate.com/welcome">Licensed By Topupmate Technology, All Rights Reserved.</a></i>
</footer>