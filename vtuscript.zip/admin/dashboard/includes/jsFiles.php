    <!-- jQuery 3 -->
    <script src="<?php echo $assetsLoc; ?>/vendor_components/jquery-3.3.1/jquery-3.3.1.min.js"></script>
	
	<!-- jQuery UI 1.11.4 -->
	<script src="<?php echo $assetsLoc; ?>/vendor_components/jquery-ui/jquery-ui.js"></script>
	
	<!-- popper -->
	<script src="<?php echo $assetsLoc; ?>/vendor_components/popper/dist/popper.min.js"></script>
	
	<!-- Bootstrap 4.0-->
	<script src="<?php echo $assetsLoc; ?>/vendor_components/bootstrap/dist/js/bootstrap.js"></script>	

    <!-- This is data table -->
    <script src="<?php echo $assetsLoc; ?>/vendor_components/datatable/datatables.min.js"></script>

	<!-- Sweet-Alert  -->
    <script src="<?php echo $assetsLoc; ?>/vendor_components/sweetalert/sweetalert.min.js"></script>
	
	<!-- Azurex Admin for Data Table -->
	<script src="<?php echo $assetsLoc; ?>/js/pages/data-table.js"></script>
	
	<!-- Slimscroll -->
	<script src="<?php echo $assetsLoc; ?>/vendor_components/jquery-slimscroll/jquery.slimscroll.js"></script>
	
	<!-- FastClick -->
	<script src="<?php echo $assetsLoc; ?>/vendor_components/fastclick/lib/fastclick.js"></script>
	
	<!-- chart.js -->
	<script src="<?php echo $assetsLoc; ?>/vendor_components/chart.js-master/Chart.min.js"></script>
	
	<!-- apexcharts -->
	<script src="<?php echo $assetsLoc; ?>/vendor_components/apexcharts-bundle/irregular-data-series.js"></script>
	<script src="<?php echo $assetsLoc; ?>/vendor_components/apexcharts-bundle/dist/apexcharts.js"></script>
	
	<!-- FLOT CHARTS -->
	<script src="<?php echo $assetsLoc; ?>/vendor_components/Flot/jquery.flot.js"></script>
	<script src="<?php echo $assetsLoc; ?>/vendor_components/Flot/jquery.flot.resize.js"></script>
	<script src="<?php echo $assetsLoc; ?>/vendor_components/Flot/jquery.flot.pie.js"></script>
	<script src="<?php echo $assetsLoc; ?>/vendor_components/Flot/jquery.flot.categories.js"></script>
	
	<!-- Sparkline -->
	<script src="<?php echo $assetsLoc; ?>/vendor_components/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
	
	<!-- include summernote css/js -->
	<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>
	<!-- Azurex Admin App -->
	<script src="<?php echo $assetsLoc; ?>/js/template.js"></script>

    
	
	<!-- Azurex Admin dashboard demo (This is only for demo purposes) -->
	<script src="<?php echo $assetsLoc; ?>/js/pages/dashboard.js"></script>